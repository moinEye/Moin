<?php
$pro=array();
require("libProject.php");
$sql1="select * from product where pName='".$_GET["pName"]."'";
loadProductFromSQL($sql1);
foreach($pro as $p)
{                                                                                                                          //this is for mySQL
    echo "<p>";
    echo "Product exist";
    echo "</p>";                                                                                             //this is for textfile
}

if(sizeof($pro)==0)
    echo "not exist...";
?>