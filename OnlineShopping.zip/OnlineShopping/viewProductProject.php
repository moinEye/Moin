Product Details
<?php
session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="success")
{
    ?>
    <html>
    <head>
        <title> Product view page</title>
    </head>
    <body>
    <br>
    <br>

    <form action="checkProductProject.php" method="post">
        Search:
        <input value="" type="text" name="txtSearchProduct">
        <input type="submit" value="Search" name="btnSearch">
        &nbsp;
        &nbsp;
        <input type="submit" value="Add" name="btnAdd">
        &nbsp;
        &nbsp;
        <input type="submit" value="Edit" name="btnEdit">
        &nbsp;
        &nbsp;
        <input type="submit" value="Delete" name="btnDelete">
        &nbsp;
        &nbsp;
        <input type="submit" value="View Product Details" name="btnDetail">
        <br>

    </form>
    </body>
    </html>

    <?php
    require("libProject.php");
//loadFromText();
//loadFromXML();
    $pro=array();
    loadProductFromSQL("select * from product");
    ?>
    <table align="center" border="5">

        <tr>
            <th>id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Available</th>
            <th>Points</th>
            <th>Category</th>
        </tr>
        <?php
        foreach ($pro as $p)
        {
            ?>
            <tr>
                <td> <?php echo $p["pId"]; ?></td>
                <td> <?php echo $p["pName"]; ?></td>
                <td> <?php echo $p["pPrice"]; ?></td>
                <td> <?php echo $p["pAvailableQty"]; ?></td>
                <td> <?php echo $p["pPoints"]; ?></td>
                <td> <?php echo $p["proCategoryId"]; ?></td>
            </tr>

            <?php


        }
        ?>
    </table>
    <?php
    echo "<br> <a href='logOutProject.php'>Log Out</a>";
    ?>

    <?php
}
else
{
    header("Location:home.php");
}
?>


