
<html>
<head>
<title>Home Page Online Shopping</title>
</head>
<body bgcolor="black">
<h1> <center> <font size="10" color="red"> Welcome To Online Shopping </font> </center> </h1>
<table>
<form action="CustomerCarePage.html" method="post">
<input type="submit" value="    Customer Care    " name="btnCusCare" /> 
</form>
&nbsp
&nbsp
&nbsp

<form action="TrackOrderPage.html" method="post">
<input type="submit" value="     Track My Order    " name="btnTrackOrder" />
</form>
&nbsp
&nbsp
&nbsp
<form action="SellOnPage.html" method="post">
<input type="submit" value="        Sell On        " name="btnSellOn" />
</form>
&nbsp
&nbsp
&nbsp
<form action="logInProject.php" method="post">
<input type="submit" value="          LogIn        " name="LogIn" />
</form>
&nbsp
&nbsp
&nbsp
<form action="SignInProject.php" method="post">
<input type="submit" value="         SignUp         " name="btnSignUp" />
</form>
</table>
<br>
<table>
<font size="5" color="white"> Decent Search : </font> <input type="text" name="search" />
&nbsp
<form action="SearchPage.html" method="post">
<input type="submit" value="     search     " name="btnSearch" />
</form>
</table>
<br>
<p align="left" > 
<font size="5" color="white"> Product Categories : </font>  

</p>
<a href="GiftPage.html"> <img src="product2.jpg" alt="This is product2" height="275" width="275" ></a>
&nbsp
&nbsp
&nbsp
&nbsp
<a href="CosmaticsPage.html"> <img src="product1.jpg" alt="This is product2" height="275" width="275"> </a>
&nbsp
&nbsp
&nbsp
&nbsp
<a href="CrocarisePage.html"> <img src="product3.jpg" alt="This is product2" height="275" width="275"> </a>
&nbsp
&nbsp
&nbsp
&nbsp
<a href="BabiesPage.html"> <img src="product4.jpg" alt="This is product2" height="275" > </a>
<br>
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
<font size="5" color="white">
 <a href="GiftPage.html">Gift Item</a> 
 </font> 
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
<font size="5" color="white">
<a href="CosmaticsPage.html">Cosmatics Item</a> 
</font> 
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
<font size="5" color="white"> 
<a href="CrocarisePage.html">Crocarise Item </a> 
</font>
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
&nbsp
<font size="5" color="white"> 
<a href="BabiesPage.html"> Babies Item <a/> 
</font>
</body>
</html>