<?php
if(isset($_POST["btnBuy"]))
{
    $pId=$_POST["txtId"];
    $qty=$_POST["txtQty"];
    require("libProject.php");
    $pro=array();
    loadProductFromSQL("select * from product");
    foreach ($pro as $p)
    {
        if($pId==$p["pId"])
        {

            if($qty<=$p["pAvailableQty"])
            {
                $pName=$p["pName"];
                $pPrice=$p["pPrice"];
                $pPoints=$p["pPoints"];
                $proCategoryId=$p["proCategoryId"];
                $pId=$p["pId"];
                echo "Total amount is:";
                echo $qty*$p["pPrice"];
                echo "<br/>";
                $updateQty=$p["pAvailableQty"]-$qty;
                ProductupdateData("update product set pName='$pName',pPrice='$pPrice',pAvailableQty='$updateQty',pPoints='$pPoints',proCategoryId='$proCategoryId'
                  where pId='$pId'");
                ?>
                <br/>
                <form action="checkPayment.php" method="post">
                    <input type="submit" value="Payment" name="btnPayment">
                </form>

                <?php
              return;
            }
            else
            {
                echo "sorry...sir...There are less amout of product";
            }
        }
    }
}

?>