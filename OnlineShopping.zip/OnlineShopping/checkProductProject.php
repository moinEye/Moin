<?php

if(isset($_POST["btnSearch"]))
{
    $productId=$_POST["txtSearchProduct"];
    require("libProject.php");
    $pro=array();
    loadProductFromSQL("select * from product");
    $t=0;
    foreach ($pro as $p)
    {
        if($productId==$p["pId"])
        {
            $t++;
            echo "exist";
            echo "<br/>";
            echo "Name:".$p["pName"];
            echo "<br/>";
            echo  "Price:".$p["pPrice"];
            echo "<br/>";
            echo "Available Quantity:".$p["pAvailableQty"];  //for textFile & MySQL
            echo "<br/>";                    //for textFile & MySQL
            //echo "Date Of Birth:".$ud["day"]."/".$ud["month"]."/".$ud["year"];  //for xml
            //echo "<br/>";                                                       //for xml
            echo "Points:".$p["pPoints"];
            echo "<br/>";
            echo "Category Id:".$p["proCategoryId"];
            return;
        }
    }
    if($t==0)
    {
        echo "not found";
    }
}
else if(isset($_POST["btnAdd"]))
{
    header("location:AddProductProject.php");
}
else if(isset($_POST["btnEdit"]))
{
    ?>
    <form action="checkProductEditProject.php" method="post">
        Enter Your Id
        <input value="" type="text" name="txtId">
        <input type="submit" value="Done" name="btnId">
        <br/>
        <br/>
        <?php
        require ("libProject.php");
        $pro=array();
        loadProductFromSQL("select * from product");
        ?>
        <table align="center" border="5">

            <tr>
                <th>id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Available</th>
                <th>Points</th>
                <th>Category</th>
            </tr>


            <?php
            foreach ($pro as $p)
            {
                ?>
                <tr>
                    <td> <?php echo $p["pId"]; ?></td>
                    <td> <?php echo $p["pName"]; ?></td>
                    <td> <?php echo $p["pPrice"]; ?></td>
                    <td> <?php echo $p["pAvailableQty"]; ?></td>
                    <td> <?php echo $p["pPoints"]; ?></td>
                    <td> <?php echo $p["proCategoryId"]; ?></td>
                </tr>

                <?php


            }
            ?>
        </table>
    </form>
    <?php
}
else if(isset($_POST["btnDelete"]))
{
    ?>
    <form action="checkProductDeleteProject.php" method="post">
        Enter Your Delete Id
        <input value="" type="text" name="txtId">
        <input type="submit" value="Done" name="btnId">
        <br/>
        <br/>
        <?php
        require ("libProject.php");
        $pro=array();
        loadProductFromSQL("select * from product");
        ?>
        <table align="center" border="5">

            <tr>
                <th>id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Available</th>
                <th>Points</th>
                <th>Category</th>
            </tr>


            <?php
            foreach ($pro as $p)
            {
                ?>
                <tr>
                    <td> <?php echo $p["pId"]; ?></td>
                    <td> <?php echo $p["pName"]; ?></td>
                    <td> <?php echo $p["pPrice"]; ?></td>
                    <td> <?php echo $p["pAvailableQty"]; ?></td>
                    <td> <?php echo $p["pPoints"]; ?></td>
                    <td> <?php echo $p["proCategoryId"]; ?></td>
                </tr>

                <?php


            }
            ?>
        </table>

    </form>
    <?php
}
else if(isset($_POST["btnDetail"]))
{
    require("libProject.php");
//loadFromText();
//loadFromXML();
    $pro=array();
    loadProductFromSQL("select * from product");
    ?>

    <table align="center" border="5" >
        <tr>
            <th>Product details</th>
            <?php
            foreach ($pro as $p)
            {
            ?>
        <tr>
            <td>
                <a href="detailProductProject.php?pId=<?php echo $p["pId"]; ?>"><?php echo $p["pName"];
                    ?></a>
            </td>
        </tr>
        <?php
        }
        ?>
        <tr/>
    </table>
    <?php
}
else if(isset($_POST["btnUser"]))
{
    header("location:viewUserProject.php");
}
else if(isset($_POST["btnProduct"]))
{
    header("location:viewProductProject.php");
}

?>
