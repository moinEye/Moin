<?php
$auth=array();
require("libProject.php");
$sql1="select * from user where phone='".$_GET["phone"]."'";
loadFromSQL($sql1);
foreach($auth as $v)
{                                                                                                                          //this is for mySQL
    echo "<p>";
    echo "Phone number is exist";
    echo "</p>";                                                                                             //this is for textfile
}

if(sizeof($auth)==0)
    echo "not exist...";
?>