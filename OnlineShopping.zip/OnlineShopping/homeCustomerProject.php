<?php
session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="success")
{
    echo "Welcome Customer...";
    ?>
    <form action="checkChooseProject.php" method="post" name="ChooseForm">
        <table align="center">
            <tr>
                <td>
                    <html>
                    <head>
                        <?php
                        require("customerLibProject.php");
                        $data=array();
                        loadFromMySQL("select * from productcategory");
                        ?>
                        <script>
                            xmlhttp = new XMLHttpRequest();
                            flag="";
                            function clearCombo(id){
                                var list=document.getElementById(id);
                                while (list.firstChild) {
                                    list.removeChild(list.firstChild);
                                }
                            }
                            function loadJSONToCombo(id,jsn){
                                var resp=JSON.parse(jsn);
                                var combo = document.getElementById(id);
                                for(i=0;i<resp.length;i++){
                                    var option = document.createElement("option");
                                    option.text = resp[i].pName;
                                    option.value = resp[i].pId;
                                    combo.add(option);
                                }
                            }
                            function loadProduct(v) {
                                str=v.value;
                                flag="loadProduct";
                                clearCombo("productList");
                                document.getElementById("spinner").style.visibility= "visible";
                                xmlhttp.onreadystatechange = function(){
                                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                                        m=document.getElementById("txtHint");
                                        loadJSONToCombo("productList",xmlhttp.responseText);
                                        document.getElementById("spinner").style.visibility= "hidden";
                                    }
                                };
                                var url="productFetchProject.php";
                                xmlhttp.open("POST", url, true);
                                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                xmlhttp.send("flag="+flag+"&proCategoryId="+str);
                            }
                        </script>
                    </head>
                    <body>
                    <p><b>Here you will show the product item & product list</b></p>
                    Select Product Category :
                    <select id="productcategoryList" onchange="loadProduct(this)" name="chooseProduct"><?php
                        foreach($data as $r){?>
                            <option value="<?php echo $r["proCategoryId"];?>">
                                <?php echo $r["proCatName"];?>
                            </option>	<?php
                        }?>
                    </select>
                    <img id="spinner" src="loading.gif" width="20px" height="20px" style="visibility:hidden">
                    <select id="productList" name="productList">
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <br/>
                    Enter your choosen product:
                    <input value="" type="text" name="txtProductName">
                </td>
            </tr>
            <tr>
                <td>
                    <br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input value="ok" type="submit" name="btnOK">
                </td>
            </tr>
        </table>
    </form>
    </body>
    </html>
    <?php
    echo "<br> <a href='logOutProject.php'>Log Out</a>";
}
else {
    header("Location:home.php");
}
?>