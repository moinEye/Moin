<?php
   //$config["dataSource"]="mysql";
   $config["dbName"]="onlineshopping";
   $config["dbUser"]="root";
   $config["dbPass"]="";
   $config["dbHost"]="localhost";
function loadFromMySQL($sql)
{
    global $data;
    global $config;
    $conn = mysqli_connect($config["dbHost"], $config["dbUser"], $config["dbPass"],$config["dbName"]);
    $result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
    $data=array();
    while($row = mysqli_fetch_assoc($result))
    {
        $data[]=$row;
    }
}

?>