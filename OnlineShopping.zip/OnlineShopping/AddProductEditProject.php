<?php
require("libProject.php");
$pId=$_POST["txtProId"];
$pName=$_POST["txtProName"];
$pPrice=$_POST["txtProPrice"];
$pAvailableQty=$_POST["txtProQty"];
$pPoints=$_POST["txtProPoints"];
$proCategoryId=$_POST["txtProCategory"];
?>
Id:
<?php
echo $pId;
echo "<br/>";
?>
    Name:
<?php
echo $pName;
echo "<br/>";
?>
    Price:
<?php
echo $pPrice;
echo "<br/>";
?>
    Available qty.:
<?php
echo $pAvailableQty;
echo "<br/>";
?>
    Points:
<?php
echo $pPoints;
echo "<br/>";
?>
    Category:
<?php
echo $proCategoryId;
echo "<br/>";

$pro=array();
ProductupdateData("update product set pName='$pName',pPrice='$pPrice',pAvailableQty='$pAvailableQty',pPoints='$pPoints',proCategoryId='$proCategoryId'
               where pId='$pId'");
?>
