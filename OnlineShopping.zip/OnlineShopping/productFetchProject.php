<?php
$data=array();
require("customerLibProject.php");
if(isset($_REQUEST["flag"]) && $_REQUEST["flag"]=="loadProduct"){
    $sql="select * from product where proCategoryId='".$_REQUEST["proCategoryId"]."'";
    loadFromMySQL($sql);
    echo json_encode($data);
}
?>