<?php
if(isset($_POST["btnPayment"]))
{
    echo "payment completed...";
    echo "<br/>";
    echo "Your Transection ID:.....";
}
?>