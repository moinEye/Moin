<?php

if(isset($_POST["btnSearch"]))
{
        $userName=$_POST["txtSearchUser"];
        require("libProject.php");
        $auth=array();
        loadFromSQL("select * from user");
        $t=0;
        foreach ($auth as $a)
        {
            if($userName==$a["firstName"])
            {
                    $t++;
                    echo "exist";
                    echo "<br/>";
                    echo "First Name:".$a["firstName"];
                    echo "<br/>";
                    echo  "Last Name:".$a["lastName"];
                    echo "<br/>";
                    echo "Date Of Birth:".$a["dob"];  //for textFile & MySQL
                    echo "<br/>";                    //for textFile & MySQL
                    //echo "Date Of Birth:".$ud["day"]."/".$ud["month"]."/".$ud["year"];  //for xml
                    //echo "<br/>";                                                       //for xml
                    echo "Gender:".$a["gender"];
                    echo "<br/>";
                    echo "Phone no.:".$a["phone"];
                    echo "<br/>";
                    echo "Email Id:".$a["email"];
                    echo "<br/>";
                    echo "Password:".$a["pass"];
                    echo "<br/>";
                    echo "User Type:".$a["userType"];
                    return;

            }
        }
        if($t==0)
        {

            echo "not found";
        }

}
else if(isset($_POST["btnAdd"]))
{
    header("location:SignInProject.php");
}
else if(isset($_POST["btnEdit"]))
{
    ?>
    <form action="checkEditProject.php" method="post">
        Enter Your Id
        <input value="" type="text" name="txtId">
        <input type="submit" value="Done" name="btnId">
        <br/>
        <br/>
        <?php
        require ("libProject.php");
        $auth=array();
        loadFromSQL("select * from user");
        ?>
        <table align="center" border="5">

            <tr>
                <th>id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Password</th>
                <th>User Type</th>
            </tr>


            <?php
            foreach ($auth as $u)
            {
                ?>
                <tr>
                    <td> <?php echo $u["id"]; ?></td>
                    <td> <?php echo $u["firstName"]; ?></td>
                    <td> <?php echo $u["lastName"]; ?></td>
                    <td> <?php echo $u["dob"]; ?></td>
                    <td> <?php echo $u["gender"]; ?></td>
                    <td> <?php echo $u["phone"]; ?></td>
                    <td> <?php echo $u["email"]; ?></td>
                    <td> <?php echo $u["pass"]; ?></td>
                    <td> <?php echo $u["userType"]; ?></td>
                </tr>

                <?php


            }
            ?>
        </table>
    </form>
    <?php
}
else if(isset($_POST["btnDelete"]))
{
    ?>
    <form action="checkDeleteProject.php" method="post">
        Enter Your Delete Id
        <input value="" type="text" name="txtId">
        <input type="submit" value="Done" name="btnId">
        <br/>
        <br/>
        <?php
        require ("libProject.php");
        $auth=array();
        loadFromSQL("select * from user");
        ?>
        <table align="center" border="5">

            <tr>
                <th>id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Password</th>
                <th>User Type</th>
            </tr>


            <?php
            foreach ($auth as $u)
            {
                ?>
                <tr>
                    <td> <?php echo $u["id"]; ?></td>
                    <td> <?php echo $u["firstName"]; ?></td>
                    <td> <?php echo $u["lastName"]; ?></td>
                    <td> <?php echo $u["dob"]; ?></td>
                    <td> <?php echo $u["gender"]; ?></td>
                    <td> <?php echo $u["phone"]; ?></td>
                    <td> <?php echo $u["email"]; ?></td>
                    <td> <?php echo $u["pass"]; ?></td>
                    <td> <?php echo $u["userType"]; ?></td>
                </tr>

                <?php


            }
            ?>
        </table>

    </form>
    <?php
}
else if(isset($_POST["btnDetail"]))
{
    require("libProject.php");
//loadFromText();
//loadFromXML();
    $auth=array();
    loadFromSQL("select * from user");
    ?>

    <table align="center" border="5" >
        <tr>
            <th>user details</th>
            <?php
            foreach ($auth as $u)
            {
            ?>
        <tr>
            <td>
                <a href="detailUserProject.php?uid=<?php echo $u["id"]; ?>"><?php echo $u["firstName"];
                    ?>
                    &nbsp;
                    <?php
                    echo $u["lastName"];?></a>
            </td>
        </tr>
        <?php
        }
        ?>
        <tr/>
    </table>
    <?php
}
else if(isset($_POST["btnUser"]))
{
    header("location:viewUserProject.php");
}
else if(isset($_POST["btnProduct"]))
{
    header("location:viewProductProject.php");
}

?>
