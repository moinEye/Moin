<?php
if(isset($_POST["btnId"]))
{
    $id = $_POST["txtId"];
    require("libProject.php");
    $auth = array();
    loadFromSQL("select * from user");
    $t=0;
    foreach($auth as $u)
    {
        if ($id == $u["id"])
        {
            $t++;
            deleteData("delete from user where id='$id'");
        }
    }
    if($t==0)
    {
        echo "no data found";

    }

}
?>
