<?php
$pro=array();
require("libProject.php");
$sql="select * from product";
loadProductFromSQL($sql);
$i=1;
foreach($pro as $p)
{
$i++;
}
if(isset($_GET["error"]))
{
echo "<span style='color:red'>".$_GET["error"]."</span>";
}
?>
<script>
    xmlhttp = new XMLHttpRequest();
    function showHint1()
    {
        str=document.getElementById("nameId").value;
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                m=document.getElementById("txtHint1");
                m.innerHTML=xmlhttp.responseText;
            }
        };
        var url="fetchProductProject.php?pName="+str;
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
    function validate()
    {
        var price=document.addProductForm.txtProPrice.value;
        var points=document.addProductForm.txtProPoints.value;
        var qty=document.addProductForm.txtProQty.value;
        var cat=document.addProductForm.txtProCategory.value;
        if(document.addProductForm.txtProName.value=="" || document.addProductForm.txtProPrice.value==""
            ||document.addProductForm.txtProQty.value=="" || document.addProductForm.txtProPoints.value==""
            || document.addProductForm.txtProCategory.value=="" || isNaN(price) || isNaN(points) || isNaN(qty)
            || isNaN(cat))
        {
            if(document.addProductForm.txtProName.value=="")
            {
                document.getElementById("msgId").innerHTML = "Invalid input";
                document.getElementById("msgId").style.color = "red";
            }
            else if(document.addProductForm.txtProPrice.value=="" || isNaN(price))
            {
                document.getElementById("msgId").innerHTML = "Invalid input";
                document.getElementById("msgId").style.color = "red";
            }
            else if(document.addProductForm.txtProPoints.value=="" || isNaN(points))
            {
                document.getElementById("msgId").innerHTML = "Invalid input";
                document.getElementById("msgId").style.color = "red";
            }
            else if(document.addProductForm.txtProQty.value=="" || isNaN(qty))
            {
                document.getElementById("msgId").innerHTML = "Invalid input";
                document.getElementById("msgId").style.color = "red";
            }
            else if(document.addProductForm.txtProCategory.value=="" || isNaN(cat))
            {
                document.getElementById("msgId").innerHTML = "Invalid input";
                document.getElementById("msgId").style.color = "red";
            }

            return false;
        }
        else
        {
            alert("valid data");
            return true;
        }
    }
</script>
<html>
<head>
    <title>Add Product Page</title>
</head>
<body>
<form action="checkAddProductProject.php" method="post" name="addProductForm">
    <p id="msgId"></p>
    <br/>
    Id:
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    <input type="text" readonly="readonly" name="txtProId" value="<?php echo $i; ?>"/>
    <br/>
    <br/>
    Name:
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    <input value="" type="text" onkeyup="showHint1()" name="txtProName" id="nameId">
    <p id="txtHint1"></p>
    <br/>
    <br/>
    price:
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    <input type="text" value="" name="txtProPrice">
    <br/>
    <br/>
    avilable Qty.:
    <input type="text" value="" name="txtProQty">
    <br/>
    <br/>
    Points:
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    <input type="text" value="" name="txtProPoints">
    <br/>
    <br/>
    category:
    &nbsp;
    &nbsp;
    &nbsp;
    <input type="text" value="" name="txtProCategory">
    <br/>
    <br/>
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    &nbsp;
    <input type="submit" onclick="return validate()" value="        Save       " />
</form>
</body>
</html>

