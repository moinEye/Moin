User Details
<?php
session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="success")
{
    ?>
    <html>
<head>
    <title> user view page</title>
</head>
<body>
<br>
<br>

<form action="checkUserProject.php" method="post">
    Search:
    <input value="" type="text" name="txtSearchUser">
    <input type="submit" value="Search" name="btnSearch">
    &nbsp;
    &nbsp;
    <input type="submit" value="Add" name="btnAdd">
    &nbsp;
    &nbsp;
    <input type="submit" value="Edit" name="btnEdit">
    &nbsp;
    &nbsp;
    <input type="submit" value="Delete" name="btnDelete">
    &nbsp;
    &nbsp;
    <input type="submit" value="View User Details" name="btnDetail">
    <br>

</form>
</body>
</html>

<?php
    require("libProject.php");
//loadFromText();
//loadFromXML();
    $auth=array();
    loadFromSQL("select * from user");
    ?>
    <table align="center" border="5">

        <tr>
            <th>id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>DOB</th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Password</th>
            <th>User Type</th>
        </tr>
        <?php
        foreach ($auth as $u)
        {
            ?>
            <tr>
                <td> <?php echo $u["id"]; ?></td>
                <td> <?php echo $u["firstName"]; ?></td>
                <td> <?php echo $u["lastName"]; ?></td>
                <td> <?php echo $u["dob"]; ?></td>
                <td> <?php echo $u["gender"]; ?></td>
                <td> <?php echo $u["phone"]; ?></td>
                <td> <?php echo $u["email"]; ?></td>
                <td> <?php echo $u["pass"]; ?></td>
                <td> <?php echo $u["userType"]; ?></td>
            </tr>

            <?php


        }
        ?>
    </table>
<?php
echo "<br> <a href='logOutProject.php'>Log Out</a>";
?>

<?php
}
else
    {
        header("Location:home.php");
    }
?>


