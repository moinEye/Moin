<?php
if(isset($_POST["btnId"]))
{
    $id = $_POST["txtId"];
    require("libProject.php");
    $pro = array();
    loadProductFromSQL("select * from product");
    $t=0;
    foreach($pro as $p)
    {
        if ($id == $p["pId"])
        {
            $t++;
            ProductdeleteData("delete from product where pId='$id'");
        }
    }
    if($t==0)
    {
        echo "no data found";

    }

}
?>