<?php
require("libProject.php");
$p=array();
getProductDetailsMySQL($_REQUEST["pId"]);
echo "Name:".$p["pName"];
echo "<br/>";
echo  "Price:".$p["pPrice"];
echo "<br/>";
echo "Available Quantity:".$p["pAvailableQty"];  //for textFile & MySQL
echo "<br/>";                    //for textFile & MySQL
//echo "Date Of Birth:".$ud["day"]."/".$ud["month"]."/".$ud["year"];  //for xml
//echo "<br/>";                                                       //for xml
echo "Points:".$p["pPoints"];
echo "<br/>";
echo "Category Id:".$p["proCategoryId"];

?>