<?php
$auth=array();
require("libProject.php");
$sql="select * from user";
loadFromSQL($sql);
$i=1;
foreach($auth as $v)
{
    $i++;
}
if(isset($_GET["error"]))
{
    echo "<span style='color:red'>".$_GET["error"]."</span>";
}
?>
<script>
    xmlhttp = new XMLHttpRequest();
    function showHint1() {
        str=document.getElementById('phnId').value;
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                m=document.getElementById("txtHint1");
                m.innerHTML=xmlhttp.responseText;
            }
        };
        var url="fetchProject.php?phone="+str;
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
    function showHint2() {
        str=document.getElementById('mailId').value;
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                n=document.getElementById("txtHint2");
                n.innerHTML=xmlhttp.responseText;
            }
        };
        var url="fetchProject2.php?email="+str;
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
     function validate() {
         var phnStr= document.singForm.txtphn.value;
         var phnRes= phnStr.substring(0,3);
         var mailStr=document.singForm.txtMail.value;
         var mailTarget1=mailStr.includes("@gmail.com");
         var mailTarget2=mailStr.includes("@yahoo.com");
         var mailTarget3=mailStr.includes("@hotmail.com");
         var pass=document.singForm.txtPass.value;
         var conPass= document.singForm.txtConPass.value;
         var userType=document.singForm.user.value;
         var genderType= document.singForm.gender.value;
         if(document.singForm.txtFirstName.value == "" || document.singForm.txtLastName.value==""
            ||  document.singForm.txtphn.value=="" || (document.singForm.txtphn.value.length!=11
                || (phnRes != "017" && phnRes!="018"
                && phnRes != "016" && phnRes != "015"))
             || ((!mailTarget1 && !mailTarget2 && !mailTarget3) || mailStr=="")
             || (pass=="" || conPass=="" || pass!=conPass) || (userType!="admin" && userType!="customer")
             || (genderType!="male" && genderType!="female"))

         {
             if(document.singForm.txtFirstName.value == "")
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }
             else if(document.singForm.txtLastName.value=="")
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }
             else if(document.singForm.txtphn.value=="" || (document.singForm.txtphn.value.length!=11
                 || (phnRes != "017" && phnRes!="018"
                     && phnRes != "016" && phnRes != "015")))
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }
             else if((!mailTarget1 && !mailTarget2 && !mailTarget3) || mailStr=="")
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }
             else if(pass=="" || conPass=="" || pass!=conPass)
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
                 document.getElementById("passId").innerHTML = "Invalid password";
                 document.getElementById("passId").style.color = "red";
             }
             else if(userType!="admin" && userType!="customer")
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }
             else if(genderType!="male" && genderType!="female")
             {
                 document.getElementById("msgId").innerHTML = "Invalid input";
                 document.getElementById("msgId").style.color = "red";
             }

             return false;
         }

         // if (document.singForm.txtFirstName.value == "" || document.singForm.txtLastName.value==""
         //     || document.singForm.txtphn.value=="" || document.singForm.txtphn.value.length!=11
         //       || (phnRes != "017" && phnRes!="018"
         //       && phnRes != "016" && phnRes != "015") || document.singForm.txtMail.value==""
         //        || (!mailTarget1 && !mailTarget2 && !mailTarget3 && mailStr==""))
         // {
         //     if(document.singForm.txtFirstName.value =="" && document.singForm.txtLastName.value==""
         //        && (document.singForm.txtphn.value=="" || document.singForm.txtphn.value.length!=11
         //             || (phnRes != "017" && phnRes!="018" && phnRes != "016" && phnRes != "015"))
         //             && ((!mailTarget1 && !mailTarget2 && !mailTarget3) || mailStr=="") )
         //     {
         //         document.getElementById("firstNameId").innerHTML = "Invalid First Name";
         //         document.getElementById("firstNameId").style.color = "red";
         //         document.getElementById("lastNameId").innerHTML="Invalid Last Name";
         //         document.getElementById("lastNameId").style.color="red";
         //         document.getElementById("phnId").innerHTML="Invalid phone number";
         //         document.getElementById("phnId").style.color="red";
         //         document.getElementById("mailId").innerHTML="Invalid email id";
         //         document.getElementById("mailId").style.color="red";
         //     }
         //     if (document.singForm.txtFirstName.value == "" && document.singForm.txtLastName.value != ""
         //         && document.singForm.txtphn.value.length==11)
         //     {
         //         document.getElementById("firstNameId").innerHTML = "Invalid First Name";
         //         document.getElementById("firstNameId").style.color = "red";
         //         document.getElementById("lastNameId").innerHTML="";
         //         document.getElementById("phnId").innerHTML="";
         //     }
         //     if (document.singForm.txtLastName.value == "" && document.singForm.txtFirstName.value !=""
         //         && document.singForm.txtphn.value.length==11)
         //     {
         //         document.getElementById("firstNameId").innerHTML = "";
         //         document.getElementById("lastNameId").innerHTML="Invalid Last Name";
         //         document.getElementById("lastNameId").style.color="red";
         //         document.getElementById("phnId").innerHTML="";
         //     }
         //     if(document.singForm.txtFirstName.value !="" && document.singForm.txtLastName.value!=""
         //        && (document.singForm.txtphn.value=="" || (document.singForm.txtphn.value.length !=11
         //            && (phnRes != "017" && phnRes!="018"
         //             && phnRes != "016" && phnRes != "015"))))
         //     {
         //         document.getElementById("firstNameId").innerHTML = "";
         //         document.getElementById("lastNameId").innerHTML="";
         //         document.getElementById("phnId").innerHTML="Invalid phone number...";
         //         document.getElementById("phnId").style.color="red";
         //     }
         //     if(document.singForm.txtFirstName.value == "" && document.singForm.txtLastName.value !=""
         //         && document.singForm.txtphn.value.length!=11)
         //     {
         //         document.getElementById("firstNameId").innerHTML = "Inavalid first name";
         //         document.getElementById("firstNameId").style.color="red";
         //         document.getElementById("lastNameId").innerHTML="";
         //         document.getElementById("phnId").innerHTML="Invalid phone number";
         //         document.getElementById("phnId").style.color="red";
         //     }
         //     if(document.singForm.txtFirstName.value != "" && document.singForm.txtLastName.value ==""
         //     && (document.singForm.txtphn.value.length!=11 || (phnRes != "017" && phnRes!="018"
         //             && phnRes != "016" && phnRes != "015")))
         //     {
         //         document.getElementById("firstNameId").innerHTML = "";
         //         document.getElementById("lastNameId").innerHTML="Invalid last name";
         //         document.getElementById("lastNameId").style.color="red";
         //         document.getElementById("phnId").innerHTML="Invalid phone number";
         //         document.getElementById("phnId").style.color="red";
         //     }
         //     if(((phnRes=="017" || phnRes=="018" || phnRes=="016" || phnRes=="015") ||
         //         document.singForm.txtphn.value!="" || document.singForm.txtphn.value.length==11)
         //         && document.singForm.txtFirstName.value == "" && document.singForm.txtLastName.value =="")
         //     {
         //         document.getElementById("firstNameId").innerHTML = "Invalid first name";
         //         document.getElementById("firstNameId").style.color="red";
         //         document.getElementById("lastNameId").innerHTML="Invalid last name";
         //         document.getElementById("lastNameId").style.color="red";
         //         document.getElementById("phnId").innerHTML="";
         //     }
         //     if(document.singForm.txtFirstName.value !="" && document.singForm.txtLastName.value!=""
         //         && (document.singForm.txtphn.value!="" || (document.singForm.txtphn.value.length==11
         //             && (phnRes == "017" && phnRes=="018" && phnRes == "016" && phnRes == "015")))
         //             && (mailStr=="" || (!mailTarget1 && !mailTarget2 && !mailTarget3)))
         //     {
         //         document.getElementById("firstNameId").innerHTML="";
         //         document.getElementById("lastNameId").innerHTML="";
         //         document.getElementById("phnId").innerHTML="";
         //         document.getElementById("mailId").innerHTML="Invalid mail id";
         //         document.getElementById("mailId").style.color="red";
         //     }

         //   return false;
         //}

         //     || document.singForm.txtPass.value !=  document.singForm.txtConPass.value
         //     || document.singForm.txtPass.value =="" || document.singForm.txtConPass.value =="")
         // {
         //     alert("Invalid data");
         //     return false;
         // }
         else
         {
             alert("Valid data");
             return true;
         }
     }
</script>
<html>
<head>
    <title> Sign In Page</title>
</head>
<body bgcolor="black">
<br>

<form action="checkSignupProject.php" method="post" name="singForm">
    <table align="center" border="3" <p style="background-color:yellow"/>
    <tr>
        <center> <font size="5" color="white">  Create Decent Account</font> <center>
                <td>
                    </br>
                    <p style="color:black;">
                    <p id="msgId"></p>
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        Id :
                        <input type="text" readonly="readonly" name="txtId" value="<?php echo $i; ?>"/>
                        <br>
                    </p>
                    <p style="color:black;">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        First Name:
                        <input value="" type="text" name="txtFirstName" />
                        <br>
                        <p id="firstNameId"></p>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        Last Name:
                        <input value="" type="text" name="txtLastName" />
                        <br>
                        <p id="lastNameId"></p>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        DOB:
                        <select name="date">
                            <option value="1">01</option>
                            <option value="2">02</option>
                            <option value="3">03</option>
                            <option value="4">04</option>
                            <option value="5">05</option>
                            <option value="6">06</option>
                            <option value="7">07</option>
                            <option value="8">08</option>
                            <option value="9">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                        </select>
                        <select name="month">
                            <option value="01">January</option>
                            <option value="02">February</option>
                            <option value="03">March</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">August</option>
                            <option value="09">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                        <select name="year">
                            <option value="1980">1980</option>
                            <option value="1981">1981</option>
                            <option value="1982">1982</option>
                            <option value="1983">1983</option>
                            <option value="1984">1984</option>
                            <option value="1985">1985</option>
                            <option value="1986">1986</option>
                            <option value="1987">1987</option>
                            <option value="1988">1988</option>
                            <option value="1989">1989</option>
                            <option value="1990">1990</option>
                            <option value="1991">1991</option>
                            <option value="1992">1992</option>
                            <option value="1993">1993</option>
                            <option value="1994">1994</option>
                            <option value="1995">1995</option>
                            <option value="1996">1996</option>
                            <option value="1997">1997</option>
                            <option value="1998">1998</option>
                            <option value="1999">1999</option>
                        </select>
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        <br>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp

                        Gender:
                        <input type="radio" name="gender" value="male"<br>
                        Male
                        <input type="radio" name="gender" value="female" <br>
                        Female
                        <br>
                        <p id="genderId"></p>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        Phone:
                        <input value="" type="text" onkeyup="showHint1()" name="txtphn" id="phnId"/>
                        <p id="txtHint1"></p>
<!--                        <p id="phnId"></p>-->
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        EmailId:
                        <input value="" type="text" onkeyup="showHint2()" name="txtMail"id="mailId" />
                        <p id="txtHint2"></p>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp

                        Password:

                        <input value="" type="password" name="txtPass" />
                        <br>
                    <p id="passId"></p>
                    </p>
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        Confirm Password:
                        <input value="" type="password" name="txtConPass" />
                        &nbsp
                        &nbsp
                    <p style="color:black">
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        &nbsp
                        User :
                        <input type="radio" name="user" value="admin"<br>
                        Admin
                        <input type="radio" name="user" value="customer" <br>
                        Customer
                        <br>
                    </p>
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    &nbsp
                    <input type="submit" onclick="return validate()" value="        Sign Up       " />
                    </p>
                    </br>
</form>
</td>
</tr>
</table>
</body>
</html>