<?php
require ("libProject.php");
$id=$_POST["txtId"];
$firstName=$_POST["txtFirstName"];
$lastName=$_POST["txtLastName"];
$date=$_POST["date"];
$month=$_POST["month"];
$year=$_POST["year"];
$dob=$date."/".$month."/".$year;
$gender=$_POST["gender"];
$phone=$_POST["txtphn"];
$email=$_POST["txtMail"];
$pass=$_POST["txtPass"];
$conPass=$_POST["txtConPass"];
$userType=$_POST["user"];
addDataMySQL("insert into user(id,firstName,lastName,dob,gender,phone,email,pass,conPass,userType) values ('$id','$firstName','$lastName','$dob','$gender','$phone','$email','$pass','$conPass','$userType')" );
$auth=array();
loadFromSQL("select * from user");
?>
<table align="center" border="5">

    <tr>
        <th>id</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>DOB</th>
        <th>Gender</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Password</th>
        <th>User Type</th>
    </tr>


    <?php
    foreach ($auth as $u)
    {
        ?>
        <tr>
            <td> <?php echo $u["id"]; ?></td>
            <td> <?php echo $u["firstName"]; ?></td>
            <td> <?php echo $u["lastName"]; ?></td>
            <td> <?php echo $u["dob"]; ?></td>
            <td> <?php echo $u["gender"]; ?></td>
            <td> <?php echo $u["phone"]; ?></td>
            <td> <?php echo $u["email"]; ?></td>
            <td> <?php echo $u["pass"]; ?></td>
            <td> <?php echo $u["userType"]; ?></td>
        </tr>

        <?php


    }
    ?>
</table>
