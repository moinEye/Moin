<?php
if(isset($_GET["error"]))
{
    echo "<span style='color: blueviolet'>".$_GET["error"]."</span>";
}
session_start();
?>
<!--<script>-->
<!--    function LogInValidity()-->
<!--    {-->
<!--        if(document.logInFm.txtPass.value.length>=5)-->
<!--        {-->
<!--            alert("Password length is correct");-->
<!--            return true;-->
<!--        }-->
<!--        else-->
<!--        {-->
<!--            //alert("Your password must have 6 charecters..");-->
<!--            document.getElementById("msg").innerHTML="Your password must have atleast 5 charecters..";-->
<!--            document.getElementById("msg").style.color="Blue";-->
<!--            return false;-->
<!--        }-->
<!--    }-->
<!---->
<!--</script>-->
<form action="checkProject.php" method="post" name="logInFm">
    <table align="center" border="3" >
        <tr>
            <td>
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                <img src="product2.jpg" alt="This is product2"  ><p style="text-align:center;color:black;background-color:white;"><font size="6">Decent Online Shopping</font></p>
            </td>
        </tr>
        <tr>
            <td>
                <p style="text-align:center;color:black;background-color:white;"><font size="8">Login   </font></p>
            </td>
        </tr>
        <tr>
            <td>
                &nbsp
                <font size="5" color="black"> User Name : </font>
                <input type="text" value="" name="txtName" />
                <br>
                &nbsp
                &nbsp
                &nbsp
                <font size="5" color="black"> Password : </font>
                <input type="password"  name="txtPass" /> <p id="msg"></p>
                <br>
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
                &nbsp
<!--                <input type="submit" onclick="return LogInValidity();" value="         Log In         " />-->
                <input type="submit" value="         Log In         " />
                <br>
                <br>
                <br>
            </td>
        </tr>
    </table>
</form>