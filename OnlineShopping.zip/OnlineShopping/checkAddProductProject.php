<?php
require ("libProject.php");
$pId=$_POST["txtProId"];
$pName=$_POST["txtProName"];
$pPrice=$_POST["txtProPrice"];
$pAvailableQty=$_POST["txtProQty"];
$pPoints=$_POST["txtProPoints"];
$proCategoryId=$_POST["txtProCategory"];
addProductDataMySQL("insert into product(pId,pName,pPrice,pAvailableQty,pPoints,proCategoryId) values ('$pId','$pName','$pPrice','$pAvailableQty','$pPoints','$proCategoryId')" );
$pro=array();
loadProductFromSQL("select * from product");
?>
<table align="center" border="5">

    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Price</th>
        <th>Available Qty.</th>
        <th>Points</th>
        <th>Category</th>
    </tr>


    <?php
    foreach ($pro as $p)
    {
        ?>
        <tr>
            <td> <?php echo $p["pId"]; ?></td>
            <td> <?php echo $p["pName"]; ?></td>
            <td> <?php echo $p["pPrice"]; ?></td>
            <td> <?php echo $p["pAvailableQty"]; ?></td>
            <td> <?php echo $p["pPoints"]; ?></td>
            <td> <?php echo $p["proCategoryId"]; ?></td>
        </tr>

        <?php


    }
    ?>
</table>
