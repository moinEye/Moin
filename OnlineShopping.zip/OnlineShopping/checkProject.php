<?php
require("libProject.php");
$auth=array();
//loadFromText();
//loadFromXML();
loadFromSQL("select * from user");
$uname=$_POST["txtName"];
$pass=$_POST["txtPass"];
$t=0;
session_start();
foreach ($auth as $a)
{
   if($uname==$a["firstName"] && $pass==$a["pass"] && $a["userType"]=="admin")
   {
       echo "valid";
       $t=1;
       $_SESSION["flag"]="success";
       header("Location:homeAdminProject.php");
       break;
   }
   if($uname==$a["firstName"] && $pass==$a["pass"] && $a["userType"]=="customer")
   {
       echo "valid";
       $t=1;
       $_SESSION["flag"]="success";
       header("Location:homeCustomerProject.php");
       break;
   }
}
if($t==0)
{
    echo "Wrong Username or Password...";
}
?>
