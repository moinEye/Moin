<?php
require("libProject.php");
$ud=array();
getUserDetailsMySQL($_REQUEST["uid"]);
//getUserDetailsText($_REQUEST["uid"]);
//getUserDetailsXML($_REQUEST["uid"]);
 echo "First Name:".$ud["firstName"];
 echo "<br/>";
 echo  "Last Name:".$ud["lastName"];
 echo "<br/>";
 echo "Date Of Birth:".$ud["dob"];  //for textFile & MySQL
 echo "<br/>";                    //for textFile & MySQL
 //echo "Date Of Birth:".$ud["day"]."/".$ud["month"]."/".$ud["year"];  //for xml
 //echo "<br/>";                                                       //for xml
 echo "Gender:".$ud["gender"];
 echo "<br/>";
 echo "Phone no.:".$ud["phone"];
 echo "<br/>";
 echo "Email Id:".$ud["email"];
 echo "<br/>";
 echo "Password:".$ud["pass"];

?>