<?php
session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="success")
{
    ?>
<!--    front page design-->
    <?php
    echo "Welcome Admin...";
    ?>
    <br/>
    <form action="checkUserProject.php" method="post">

        <br/>
    <input type="submit" value="User" name="btnUser"/>
        <input type="submit" value="Product" name="btnProduct"/>
    </form>
    <?php
    echo "<br> <a href='logOutProject.php'>Log Out</a>";
    ?>
    <?php
}
else {
    header("Location:home.php");
}
?>