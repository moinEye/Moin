<?php
session_start();
$_SESSION["flag"]="";
header("Location:home.php");
?>