<?php
$productName=$_POST["txtProductName"];
require("libProject.php");
$pro=array();
loadProductFromSQL("select * from product");
$t=0;
foreach ($pro as $p)
{
    if($productName==$p["pName"])
    {
        $t++;
        echo "Product details:";
        echo "<br/>";
        echo "Name:";
        echo $p["pName"];
        echo "<br/>";
        echo "Price:";
        echo $p["pPrice"];
        echo "<br/>";
        echo "Available Qty:";
        echo $p["pAvailableQty"];
        echo "<br/>";
        echo "Points:";
        echo $p["pPoints"];
        ?>
        <script>
            function validate()
            {
                var qty=document.BuyformForm.txtQty.value;
                if(qty=="" || isNaN(qty))
                {
                    document.getElementById("msgId").innerHTML = "Invalid input";
                    document.getElementById("msgId").style.color = "red";
                    return false;
                }
                else
                {
                    alert("valid data");
                    return true;
                }
            }


        </script>
        <form action="chechBuyProject.php" method="post" name="BuyformForm">
            <p id="msgId"></p>
            <table align="center">
                <tr>
                    <td>
                        Product Id:
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <input value="<?php echo $p["pId"]; ?>" readonly="readonly" type="text" name="txtId">
                        <br/>
                        <br/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Amount of product:
                        <input value="" type="text" name="txtQty">
                        <br/>
                        <br/>
                    </td>
                </tr>
                <tr>
                    <td>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" onclick="return validate()" value="    Buy    " name="btnBuy">
                    </td>
                </tr>
            </table>

        </form>
        <?php
    }
}
if($t==0)
{
    echo "product not found";
}
?>


