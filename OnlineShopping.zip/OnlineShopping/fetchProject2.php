<?php
$auth=array();
require("libProject.php");
$sql2="select * from user where email='".$_GET["email"]."'";
loadFromSQL($sql2);
foreach($auth as $v)
{                                                                                                                          //this is for mySQL
    echo "<p>";
    echo "Email Id is exist";
    echo "</p>";                                                                                             //this is for textfile
}

if(sizeof($auth)==0)
    echo "not exist...";
?>