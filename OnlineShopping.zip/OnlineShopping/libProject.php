<?php
function loadFromText()
{
global $auth;
$file=fopen("Users.txt","r") or die("Unable to open the file");
$auth=array();
while($line=fgets($file))
{
    $ar=explode(" ",$line);
    $auth[]=array("id"=>$ar[0],"firstName"=>$ar[1],"lastName"=>$ar[2],"DOB"=>$ar[3],"gender"=>$ar[4],
    "phoneNo"=>$ar[5],"email"=>$ar[6],"pass"=>$ar[7],"conPass"=>$ar[8],
    "userType"=>$ar[9]);
}
?>
<!--    <pre>-->
    <?php
//print_r($auth);
?>
<!--    </pre>-->
<?php
}
function loadFromXML()
{
    global $auth;
    $auth=array();
    $xml=simplexml_load_file("Users.xml") or die("Error:Unable to open the xml file");
    foreach ($xml->user as $us)
    {
        $ar=array();
        $ar["id"]=(string)$us->id;
        $ar["firstName"]=(string)$us->firstName;
        $ar["lastName"]=(string)$us->lastName;
        $ar["day"]=(string)$us->day;
        $ar["month"]=(string)$us->month;
        $ar["year"]=(string)$us->year;
        $ar["gender"]=(string)$us->gender;
        $ar["phone"]=(string)$us->phone;
        $ar["email"]=(string)$us->email;
        $ar["pass"]=(string)$us->pass;
        $ar["conPass"]=(string)$us->conPass;
        $ar["userType"]=(string)$us->userType;
        $auth[]=$ar;
    }
    ?>
<!--    <pre>-->
    <?php
   // print_r($auth);
    ?>
<!--    </pre>-->
    <?php
}
function loadFromSQL($sql)
{
    global $auth;
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    $auth=array();
    while($row=mysqli_fetch_assoc($result))
    {
        $ar=array();
        $ar["id"]=$row["id"];
        $ar["firstName"]=$row["firstName"];
        $ar["lastName"]=$row["lastName"];
        $ar["dob"]=$row["dob"];
        $ar["gender"]=$row["gender"];
        $ar["phone"]=$row["phone"];
        $ar["email"]=$row["email"];
        $ar["pass"]=$row["pass"];
        $ar["conPass"]=$row["conPass"];
        $ar["userType"]=$row["userType"];
        $auth[]=$ar;
    }
    /*?>
    <pre>
    <?php
    print_r($auth);
    ?>
    </pre>
    <?php*/

}
function getUserDetailsText($uid)
{
global $ud;
$file=fopen("Users.txt","r") or die("Unable to open the file");
$ud=array();
while($line=fgets($file))
{
    $ar=explode(" ",$line);
    if($uid==$ar[0])
    {
        $ud["lastName"]=$ar[1];
        $ud["dob"]=$ar[2];
        $ud["gender"]=$ar[3];
        $ud["phone"]=$ar[4];
        $ud["email"]=$ar[5];
        $ud["pass"]=$ar[6];
    }
}
}
function getUserDetailsXML($uid)
{
    global $ud;
    $ud=array();
    $xml=simplexml_load_file("Users.xml") or die("Error:Unable to open the xml file");
    foreach ($xml->user as $us)
    {
        $id=(string)$us->id;
        if($uid==$id)
        {
            $ud["id"]=(string)$us->id;
            $ud["firstName"]=(string)$us->firstName;
            $ud["lastName"]=(string)$us->lastName;
            $ud["day"]=(string)$us->day;
            $ud["month"]=(string)$us->month;
            $ud["year"]=(string)$us->year;
            $ud["gender"]=(string)$us->gender;
            $ud["phone"]=(string)$us->phone;
            $ud["email"]=(string)$us->email;
            $ud["pass"]=(string)$us->pass;
            $ud["conPass"]=(string)$us->conPass;
            $ud["userType"]=(string)$us->userType;
            $auth[]=$ud;
        }
    }
}
function getUserDetailsMySQL($uid)
{
    global $ud;
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,"select * from user") or die(mysqli_error($conn));
    $ud=array();
    while($row=mysqli_fetch_assoc($result))
    {
        if($uid==$row["id"])
        {
            $ud["firstName"]=$row["firstName"];
            $ud["lastName"]=$row["lastName"];
            $ud["dob"]=$row["dob"];
            $ud["gender"]=$row["gender"];
            $ud["phone"]=$row["phone"];
            $ud["email"]=$row["email"];
            $ud["pass"]=$row["pass"];
        }
    }
}
function addDataMySQL($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "not inserted";

    }
    else
    {
        echo "inserted";


    }
}
function updateData($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "not updated";
    }
    else
    {
        echo "updated";
    }


}
function deleteData($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "not deleted";

    }
    else
    {
        echo "deleted";


    }
}
function loadProductFromSQL($sql)
{
    global $pro;
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    $pro=array();
    while($row=mysqli_fetch_assoc($result))
    {
        $p=array();
        $p["pId"]=$row["pId"];
        $p["pName"]=$row["pName"];
        $p["pPrice"]=$row["pPrice"];
        $p["pAvailableQty"]=$row["pAvailableQty"];
        $p["pPoints"]=$row["pPoints"];
        $p["proCategoryId"]=$row["proCategoryId"];
        $pro[]=$p;
    }
}
function getProductDetailsMySQL($pId)
{
    global $p;
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,"select * from product") or die(mysqli_error($conn));
    $p=array();
    while($row=mysqli_fetch_assoc($result))
    {
        if($pId==$row["pId"])
        {
            $p["pId"]=$row["pId"];
            $p["pName"]=$row["pName"];
            $p["pPrice"]=$row["pPrice"];
            $p["pAvailableQty"]=$row["pAvailableQty"];
            $p["pPoints"]=$row["pPoints"];
            $p["proCategoryId"]=$row["proCategoryId"];
        }
    }

}
function addProductDataMySQL($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "Not saved Product";

    }
    else
    {
        echo "Saved Product";


    }
}
function ProductupdateData($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "not updated";
    }
    else
    {
        echo "updated";
    }
}
function ProductdeleteData($sql)
{
    $conn=mysqli_connect("localhost","root","","onlineshopping");
    $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if(!$result)
    {
        echo "not deleted";

    }
    else
    {
        echo "deleted";


    }
}
?>

