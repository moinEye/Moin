<?php
require("libProject.php");
$id=$_POST["txtId"];
$firstName=$_POST["txtFirstName"];
$lastName=$_POST["txtLastName"];
$date=$_POST["date"];
$month=$_POST["month"];
$year=$_POST["year"];
$dob=$date."/".$month."/".$year;
$gender=$_POST["gender"];
$phone=$_POST["txtphn"];
$email=$_POST["txtMail"];
$pass=$_POST["txtPass"];
$conPass=$_POST["txtConPass"];
$userType=$_POST["user"];
?>
Id:
<?php
echo $id;
echo "<br/>";
?>
    First name:
<?php
echo $firstName;
echo "<br/>";
?>
    Last name:
<?php
echo $lastName;
echo "<br/>";
?>
    DOB:
<?php
echo $dob;
echo "<br/>";
?>
    Gender:
<?php
echo $gender;
echo "<br/>";
?>
    Phone:
<?php
echo $phone;
echo "<br/>";
?>
    Email:
<?php
echo $email;
echo "<br/>";
?>
    Password:
<?php
echo $pass;
echo "<br/>";
?>
    User Type:
<?php
echo $userType;
echo "<br/>";

$auth=array();
updateData("update user set firstName='$firstName',lastName='$lastName',dob='$dob',gender='$gender',phone='$phone',email='$email',pass='$pass',conPass='$conPass',userType='$userType'
               where id='$id'");
?>

